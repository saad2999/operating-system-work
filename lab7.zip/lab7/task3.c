#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
int main(int argc,char**argv)
{
    //int x=fork();
        printf("Loading min.out file \n");
        execv("min.out",argv);
    
}
