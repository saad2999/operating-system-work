#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
int main(int argc,char**argv)

{
   printf("min.c loaded\n");

   int count = (argc-1), k=1;
    int *array=(int*) malloc(count*sizeof(int));
    for(int i=0;i<count;i++)
    {
        array[i]=atoi(argv[k]);
        k++;
       
       
        
    }
    int manimum=array[0];
    for(int i=0;i<1;i++)
    {
        for(int j=0;j<count;j++)
        {
            if(array[j]<manimum)
            {
                manimum=array[j];

            }
            
        }
    }
    printf("minimum=%d\n",manimum);
}
