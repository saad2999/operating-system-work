#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
int main()
{
    /*int x=fork();
    if(x==0)
    {
    printf("execl output\n");
    execl("/bin/ls","ls","-a","-l");
    }*/
    int y=fork();
    if(y==0)
    {
        printf("execv output\n");
      static char* array[]=  {"ls","-a","-l",NULL};
        execv("/bin/ls",array);
    }
    

    

}
