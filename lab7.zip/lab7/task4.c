#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#define READ 0
#define WRITE 1
int main()
{
 printf("executing...");
   
int fd[2];
pipe(fd);
dup2(fd[0], 0);
//dup2(fd[1], 1);
char *str ="saad";
char *readData=(char *)malloc(sizeof(char)*100);

write(fd[WRITE],str,strlen(str)+1);
read(fd[READ],readData,strlen(str)+1);

printf("%s\n", readData);
return 0;
}
