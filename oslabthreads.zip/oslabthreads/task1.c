
#include <stdio.h>
#include<pthread.h>
#include <unistd.h>
#include <stdlib.h>

struct perms{
    int* array;
    int size;
};

void* even(void* nums)
{
    struct perms *obj=(struct perms*) nums;
    int* array=obj->array;
    int size=obj->size;
    int evenarray[size];
    int evenSize=0;
    for (int i=0; i<size; i++)
    {
        if(array[i]%2==0)
        {
            evenarray[evenSize]=array[i];
            evenSize++;

        }
    }
        printf("\neven numbers are: ");
        for (int i=0; i<evenSize; i++) 
        {
        printf("%d ",evenarray[i]);
        }
        printf("\n");
    

    

    return NULL;
}
void* odd(void* nums)
{
    struct perms *obj=(struct perms*) nums;
    int* array=obj->array;
    int size=obj->size;
    int oddarray[size];
    int oddSize=0;
    for (int i=0; i<size; i++)
    {
        if(array[i]%2!=0)
        {
            oddarray[oddSize]=array[i];
            oddSize++;

        }
    }
        printf("\nodd numbers are: ");
        for (int i=0; i<oddSize; i++) 
        {
        printf("%d ",oddarray[i]);
        }
        printf("\n");
    



    return NULL;
}


int main(int argc,char**argv)
{
    
    
    int count = argc;
    int *array=(int*) malloc((count)*sizeof(int));
    for(int i=1;i<argc;i++)
    {
        
        array[i-1]=atoi(argv[i]);
        
   }
    struct perms pass;
    pass.array=array;
    pass.size=count-1;
    pthread_t eventhread;
    pthread_t oddthread;
    void* ptr=(void*) &pass;
    pthread_create(&eventhread,NULL,even,ptr);
    pthread_join(eventhread,NULL);

    pthread_create(&oddthread,NULL,odd,ptr);
    pthread_join(oddthread,NULL);
    
   


}