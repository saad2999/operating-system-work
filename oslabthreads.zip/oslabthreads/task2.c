#include <stdio.h>
#include<pthread.h>
#include <unistd.h>
#include <stdlib.h>

void* factorial(void* num)
{
    int* temp=(int*) num;
    int number=*temp;
    int factorial=1;
    if (number==0) {
      temp=&factorial;
      return (void*)temp;
    
    }
    for(int i=1;i<=number;++i)
    {
      factorial*=i;
    }
    temp=&factorial;
    //printf("%d",factorial);


  return (void*) temp; 
} 

int main()
{
  int n,p,nMinusp;
  int *t,*t2,*t3;
  void* pointer,*pointer1,*pointer2;
  printf("enter value of n\n");
  scanf("%d",&n);
  printf("enter value of p\n");
  scanf("%d",&p);
  nMinusp=n-p;
  pthread_t Nthread;
  pthread_t pthread;
  pthread_t npthread;
  t=&n;
  pointer=(void*) t;
  t2=&p;
  pointer1=(void*)t2;
  t3=&nMinusp;
  pointer2=(void*) t3;
  pthread_create(&Nthread,NULL,factorial,pointer);
  pthread_create(&pthread,NULL,factorial,pointer1);
  pthread_create(&npthread,NULL,factorial,pointer2);
  pthread_join(Nthread,pointer);
  pthread_join(pthread,pointer1);
  pthread_join(npthread,pointer2);
  t=(int*)pointer;
  n=*t;
  t2=(int*)pointer1;
  p=*t2;
  t3=(int*)pointer2;
  nMinusp=*t3;
  //printf("%d\n",*t);
  //printf("%d\n",*t2);
  //printf("%d\n",nMinusp);
  int result=n/(nMinusp*p);
  printf("result=%d",result);
  



  
}
