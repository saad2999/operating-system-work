#include"stdio.h"
#include"stdlib.h"
#include"pthread.h"
#include"unistd.h"
const int  Size= 10000;
void Sort(int *arr,int start,int end)
{
    for (int i = start; i < end; i++)
    {
        for (int j = start; j < end; j++)
        {
            if (arr[j]>arr[j+1])
            {
                int temp=arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;

            }
            
            
        }
        
    }
    
    
}

int main()
{
    int arr[Size];
    for (int i = 0; i < Size; i++)
    {
        arr[i]=rand()%(30-1+1)+1;
    }
    Sort(arr,0,Size);
    
    /* for (int i = 0; i < Size; i++)
    {
        printf("%d\n",arr[i]);
    }*/
    

}
