#include"stdio.h"
#include"stdlib.h"
#include"pthread.h"
#include"unistd.h"
int Size= 10000;
struct perms{
    int* array;
    int size;
    int start;
};
int* myarraycopy(int start,int end,int*array)
{
    int* newarray=(int*) malloc(end * sizeof(int)); 
    for (int i = start; i < end; i++)
    {
        newarray[i]=array[i];
    }
    return newarray;
    
}
void* Sort(void* Perms)
{
    struct perms *obj=(struct perms*) Perms;
    int* arr=obj->array;
    int end=obj->size;
    int start=obj->start;
    for (int i = 0; i < end; i++)
    {
        for (int j = start; j < end; j++)
        {
            if (arr[j]>arr[j+1])
            {
                int temp=arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;

            }
            
            
        }
        
    }
    
    
}

int main(int argc,char**argv)
{
   
    int array[Size];
    int Numofthreads=atoi(argv[1]);
    for (int i = 0; i < Size; i++)
    {
        array[i]=rand()%(30-1+1)+1;
    }
    pthread_t threadArray[Numofthreads];
    int mainSize=Size/Numofthreads;
     struct perms pass;
     int *array2d[Numofthreads];
    for(int i=0;i<Numofthreads;i++)
   {
     array2d[i]=myarraycopy((i*mainSize),(mainSize*(i+1)),array); 
    pass.array=array2d[i];
    pass.size=(mainSize*(i+1));
    pass.start=(i*mainSize);
     void* ptr=(void*) &pass;
    pthread_create(&threadArray[i],NULL,Sort,ptr);
    pthread_join(threadArray[i],NULL);

   }
   /*for (int i = 0; i < Numofthreads; i++)
   {
       printf("thread %d sort\n",i);
       for (int j = (i*mainSize); j < (mainSize*(i+1)); j++)
       {
           printf("%d\n",array2d[i][j]);
       }
       printf("\n");
       
   }*/
   
    

}
