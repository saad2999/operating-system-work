#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#define Read 0
#define Write 1
int main() {
  int var = 20;
  int fd[2];
  int fd2[2];
  int var2=0;
  int pid;
  pipe(fd);
  pipe(fd2);
  pid = fork();
  if (pid==-1) {
  printf("failed");
  }
  
  if(pid>0)
  {
  close(fd[Read]);
  close(fd2[Write]);
  write(fd[Write], &var, sizeof(var));
 
    read(fd2[Read], &var2, sizeof(var2));
    printf("var=%d\n", var2);
  }
  if (pid == 0) {
    
   close(fd[Write]);
   close(fd2[Read]);
    read(fd[Read], &var2, sizeof(var2));
    printf("var=%d\n", var2);
    var=var*2;
    write(fd2[Write], &var, sizeof(var));
    
  }


  return 0;
}