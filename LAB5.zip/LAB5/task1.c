#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#define READ 0
#define WRITE 1
int main()
{
int fd[2];
pipe(fd);
char *str ="saad";
char *readData=(char *)malloc(sizeof(char)*100);
write(fd[WRITE],str,strlen(str)+1);
read(fd[READ],readData,strlen(str)+1);
printf("%s\n", readData);
return 0;
}
