
#include <stdio.h>
#include<pthread.h>
#include <unistd.h>
#include <stdlib.h>

struct perms{
    int* array;
    int size;
    int start;
};

void Sort(int *arr,int size)
{
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            if (arr[j]>arr[j+1])
            {
                int temp=arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;

            }
            
            
        }
        
    }
    
    
}

void* sum(void* nums)
{
  printf("Thread 1 Loading...\n");
    struct perms *obj=(struct perms*) nums;
    int* array=obj->array;
    int size=obj->size;
    int s=obj->start;
    int sum=0;
    for (int i = s; i < size; i++)
    {
      sum=sum+array[i];
      printf("%d ",array[i]);
      
    }
    printf(" reading....\n");
    printf("Sum is %d\n",sum);
    
    

    return NULL;
}
void* mean(void* nums)
{
  printf("Thread 2 Loading...");
    struct perms *obj=(struct perms*) nums;
    int* array=obj->array;
    int size=obj->size;
    int s=obj->start;
    int sum=0;
    for (int i = s; i < size; i++)
    {
      sum=sum+array[i];
      printf("%d ",array[i]);
      
    }
    printf(" reading....\n");
    printf("Average %d",sum/size);
    
    

    return NULL;
}
void* meadin(void* nums)
{
  printf("\nThread 3 Loading...\n");
    struct perms *obj=(struct perms*) nums;
    int* array=obj->array;
    int size=obj->size;
    int s=obj->start;
    
    for (int i = s; i < size; i++)
    {
      
      printf("%d ",array[i]);
      
    }
    Sort(array,size);
    double meadian=0;
    if (size%2!=0)
    {
      
      meadian=array[size/2];
    }
    else
      meadian=(array[(size - 1) / 2] + array[size / 2]) / 2.0;
    
    printf(" reading....\n");
    printf("meadian %lf\n",meadian);
    
}
int main(int argc,char**argv)
{
    
    
    int count = argc;
    int *array=(int*) malloc((count)*sizeof(int));
    
    for(int i=1;i<argc;i++)
    {
        
        array[i-1]=atoi(argv[i]);
        
   }
   int n=(count-1)/3;
    struct perms pass;
    pass.array=array;
    pass.size=n;
    pass.start=0;

    struct perms pass1;
    pass1.array=array;
    pass1.size=n*2;
    pass1.start=n;

    struct perms pass2;
    pass2.array=array;
    pass2.size=n*3;
    pass2.start=n*2;


    pthread_t sumth;
    pthread_t meanthr;
    pthread_t meadianthr;
    void* ptr=(void*) &pass;
    void* ptr1=(void*) &pass1;
     void* ptr2=(void*) &pass2;
    pthread_create(&sumth,NULL,sum,ptr);
    pthread_join(sumth,NULL);

    pthread_create(&meanthr,NULL,mean,ptr1);
    pthread_join(meanthr,NULL);

    pthread_create(&meadianthr,NULL,meadin,ptr2);
    pthread_join(meadianthr,NULL);
   


}