#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/shm.h>
#include<sys/types.h>
#include<wait.h>

int main()
{
    int id =shmget(313, 32, IPC_CREAT|0777);
    char* ptr= shmat(id, NULL, 0777);
    sprintf(ptr,"wellcome to os\n");
    while(1);


}
