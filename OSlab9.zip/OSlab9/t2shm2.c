#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/shm.h>
#include<sys/types.h>
#include<wait.h>

int main(int argc ,char** argv)
{
    int id=shmget(313, argc*sizeof(int), IPC_CREAT|0666);
   int* ptr=shmat(id,NULL,0666);
    printf("intigers written on share memory are %d and  %d",ptr[0],ptr[1]);
    printf("\nmutiplcation= %d\n",ptr[0]*ptr[1]);

}