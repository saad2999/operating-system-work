#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/shm.h>
#include<sys/types.h>
#include<wait.h>

int main(int argc ,char** argv)
{
    int id=shmget(313, argc*sizeof(int), 0666|IPC_CREAT);
   int* ptr=shmat(id,NULL,0666);
   ptr[0]=atoi(argv[1]);
   ptr[1]=atoi(argv[2]);
  // printf("intigers written on share memory are %d and  %d",ptr[0],ptr[1]);
   while(1);
}