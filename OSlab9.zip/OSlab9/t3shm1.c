#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/shm.h>
#include<sys/types.h>
#include<wait.h>

int main(int argc ,char** argv)
{
    int id=shmget(313, (argc)*sizeof(int), 0666|IPC_CREAT);
   int* ptr=shmat(id,NULL,0666);
   printf("%d",argc);
   ptr[0]=argc;
   for(int i=1;i<argc;i++)
   {
    ptr[i]=atoi(argv[i]);
    }
  
   while(1);
}